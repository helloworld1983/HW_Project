#define _CRT_SECURE_NO_WARNINGS
#include "Manager.h"

int main(void)
{
	Manager ds;
	ds.run("command.txt");

	return 0;
}